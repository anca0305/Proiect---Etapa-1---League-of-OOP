package common;

public final class Constants {

    private Constants() {
    }
    public static final int DEFAULTVALUE = 0;
    public static final int MINHPFORLEVEL1 = 250;
    public static final int HPLEVELUP = 50;
    public static final int SETXP = 200;
    public static final int XPPERLEVEL = 40;
    public static final int INITIALHPK = 900;
    public static final int INITIALHPP = 500;
    public static final int INITIALHPR = 600;
    public static final int INITIALHPW = 400;
    public static final int HPPERLEVELK = 80;
    public static final int HPPERLEVELP = 50;
    public static final int HPPERLEVELR = 40;
    public static final int HPPERLEVELW = 30;
    public static final float BONUSDAMAGEK = 0.15f;
    public static final float BONUSDAMAGEP = 0.25f;
    public static final float BONUSDAMAGER = 0.15f;
    public static final float BONUSDAMAGEW = 0.1f;
    public static final float DEFAULTRACEAMPIFICATION = 0.0f;
    public static final float RACEAMPIFICATION08 = 0.8f;
    public static final float RACEAMPIFICATION09 = 0.9f;
    public static final float RACEAMPIFICATION10 = 1.0f;
    public static final float RACEAMPIFICATION105 = 1.05f;
    public static final float RACEAMPIFICATION11 = 1.1f;
    public static final float RACEAMPIFICATION115 = 1.15f;
    public static final float RACEAMPIFICATION12 = 1.2f;
    public static final float RACEAMPIFICATION125 = 1.25f;
    public static final float RACEAMPIFICATION13 = 1.3f;
    public static final float RACEAMPIFICATION14 = 1.4f;
    public static final float CRITICALAMPIFICATION = 1.5f;
    public static final int INITIALPERIODICDAMAGEP = 50;
    public static final int PERIODICDAMAGEPERLEVELP = 30;
    public static final int ROUNDSTORECEIVEPERIODICDAMAGEP = 2;
    public static final int ROUNDSTORECEIVEPERIODICDAMAGER = 6;
    public static final float DEFAULTPROCENTAGEFAW = 0.2f;
    public static final float PROCENTAGEPERLEVELFAW = 0.05f;
    public static final float DEFAULTPROCENTAGESAW = 0.35f;
    public static final float MAXPROCENTAGESAW = 0.7f;
    public static final float PROCENTAGEPERLEVELSAW = 0.02f;
    public static final float AMPLIFICATIONW = 0.3f;
    public static final int NOROUNDSFORCRITICALHIT = 3;
    public static final int INITIALDAMAGEFAR = 200;
    public static final int DAMAGEPERLEVELFAR = 20;
    public static final int INITIALDAMAGESAR = 40;
    public static final int DAMAGEPERLEVELSAR = 10;
    public static final int INITIALDAMAGEFAP = 350;
    public static final int DAMAGEPERLEVELFAP = 50;
    public static final int INITIALDAMAGESAP = 150;
    public static final int DAMAGEPERLEVELSAP = 20;
    public static final int INITIALDAMAGEFAK = 200;
    public static final int DAMAGEPERLEVELFAK = 30;
    public static final int INITIALDAMAGESAK = 100;
    public static final int DAMAGEPERLEVELSAK = 40;
    public static final int PROCENTAGEHPILIMITFAK = 20;
    public static final int PROCENTAGEHPSLIMITFAK = 40;
    public static final float PROCENTAGEFAK = 0.2f;
}
